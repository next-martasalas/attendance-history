---
title: Contexto del Usuario
parent: Contexto
nav_order: 1
---

# Contexto del usuario