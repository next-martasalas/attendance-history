---
title: Introduccion
has_children: false
nav_order: 1
---

# Introducción a las experiencias omnicanal

## ¿Qué es la omnicanalidad?

La omnicanalidad pone al usuario en el centro del sistema y, de forma proactiva, trata de comprender su contexto en tiempo real aprendiendo de los datos que se obtienen. Además, evalúa el coste de cambiar a otros canales disponibles y ofrece aquellos que mejoran la experiencia.